create function update_book_function()
  returns trigger
language plpgsql
as $$
BEGIN
update book set book_name=TG_ARGV[0] where book_id=TG_ARGV[1];
end;
$$;

alter function update_book_function()
  owner to ankit;

