create function myfunction()
  returns trigger
language plpgsql
as $$
BEGIN
  raise EXCEPTION 'error';
end;
$$;

alter function myfunction()
  owner to ankit;

